
Math Games Assignment - English
Contains three simple interactive games for Grades 4-7.
Folders:
- lcm/        -> LCM Finder Game (HTML + JS)
- hcf/        -> HCF Treasure Hunt
- algebra/    -> Algebra Balance Game (HTML + JS)
- common/     -> shared CSS
- backend/    -> simple PHP endpoint (submit_score.php) to log submissions (demo)

Instructions:
Open the relevant index.html in a browser. If you want to test PHP backend, run on XAMPP/WAMP/LAMP.
